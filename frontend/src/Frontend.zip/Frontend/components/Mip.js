export const Mip = [
    {
        title: 'Profil',
        path: '/profile',
        cName: 'dropdown-link'
      },
    {
      title: 'logout',
      path: '#',
      cName: 'dropdown-link'
    }
    
  
  ];
  