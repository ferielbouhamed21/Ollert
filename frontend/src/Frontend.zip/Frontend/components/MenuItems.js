export const MenuItems = [
  {
    title: 'Ajouter un nouveau projet',
    path: '/ajout',
    cName: 'dropdown-link'
  },
  {
    title: 'Consulter les projets',
    path: '/consulter',
    cName: 'dropdown-link'
  }

];
