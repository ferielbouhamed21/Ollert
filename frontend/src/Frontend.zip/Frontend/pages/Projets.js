import React from 'react';
import Footer from '../components/Footer';
const Projets = () => {
    return (
        <div>
            Projects
            <Footer />
        </div>
    );
};

export default Projets;