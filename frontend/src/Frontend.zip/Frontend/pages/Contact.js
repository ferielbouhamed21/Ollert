import React from 'react';

const Contact = () => {
    return (
        <div>
            contact
        </div>
    );
};

export default Contact;