import React from 'react';
import Footer from '../components/Footer';

export default function Consulter() {
  return (
    <div>
      <h1 className='consulter'>consulter les projets</h1>
      <Footer />
    </div>
  );
}
