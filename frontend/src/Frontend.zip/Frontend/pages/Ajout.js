import React from 'react';
import Footer from '../components/Footer';

export default function Ajout() {
  return (
    <>
      <h1 className='ajout'>ajout projet</h1>
      <Footer />
    </>
  );
}
